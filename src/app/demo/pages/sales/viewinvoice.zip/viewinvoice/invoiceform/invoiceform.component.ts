import { Component, OnInit } from '@angular/core';
import { SalesService } from "../../../finance/sales/sales.service";
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
@Component({
  selector: 'app-invoiceform',
  templateUrl: './invoiceform.component.html',
  styleUrls: ['./invoiceform.component.scss']
})
export class InvoiceformComponent implements OnInit {
  SaleForm: FormGroup;
  constructor( private salesService:SalesService,private fb:FormBuilder, ) { }

  ngOnInit() {
    this.salesService.getInvProduct().subscribe(data=>{
      console.log(data)
    })
    this.SaleForm = this.fb.group({
      name:[''],
      date:[''],
      billAddress:[''],
      shipAddress:[''],
      contactNumber:[''],
      cost:[''],
      products: this.fb.array([this.createItem()])
      })

  }

  createItem() {
    return this.fb.group({
    _id:[''],
    itemCode:[''],
		description:[''],
		hsnCode:[''],
		vom:[''],
		custQuantity:[''],
		unitRate:[''],
		CGST:[''],
    SGST:[''],
    col33: [0],
    col34:[0],
    col35:[0],

    })
  }

}
