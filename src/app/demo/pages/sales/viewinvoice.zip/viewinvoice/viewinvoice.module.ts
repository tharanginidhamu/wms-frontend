import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewinvoiceComponent } from './viewinvoice.component';
import { ViewinvoiceRoutingModule } from './viewinvoice-routing.module';
import {SharedModule} from '../../../../theme/shared/shared.module';
import {NgbDropdownModule} from '@ng-bootstrap/ng-bootstrap';
import { InvoiceformComponent } from './invoiceform/invoiceform.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
  declarations: [ ViewinvoiceComponent,InvoiceformComponent ],
  imports: [
    CommonModule,
    ViewinvoiceRoutingModule,
    SharedModule,
    NgbDropdownModule,
    DataTablesModule
  ]
})
export class ViewinvoiceModule { }
