import { Component, OnInit } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { SalesService } from "../../../pages/finance/sales/sales.service";
import { Subject } from 'rxjs';
import 'rxjs/add/operator/map';
@Component({
  selector: 'app-viewinvoice',
  templateUrl: './viewinvoice.component.html',
  styleUrls: ['./viewinvoice.component.scss']
})
export class ViewinvoiceComponent implements OnInit {
getData;
dtOptions: DataTables.Settings = {};
dtTrigger: Subject<any> = new Subject();
  constructor(private router:Router, private billingService:SalesService) { }

  ngOnInit() {
    this.billingService.getInvProduct().subscribe(data=>{
      this.getData=data;
      console.log(this.getData)
      this.dtTrigger.next();
    })
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10
    };
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
  invoiceform()
  {
    localStorage.removeItem('sup')
    this.router.navigate(['/saless/viewinvoice/invoiceform'])
  }

}
