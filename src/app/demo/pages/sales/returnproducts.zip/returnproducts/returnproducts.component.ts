import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-returnproducts',
  templateUrl: './returnproducts.component.html',
  styleUrls: ['./returnproducts.component.scss']
})
export class ReturnproductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
