import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class ReturnService {

  constructor( private http:HttpClient) { }

  getReturn(){
    return this.http.get('http://localhost:3350/returnproduct')
  }
  postReturn(value){
    return this.http.post('http://localhost:3350/returnproduct', value)
  }
  putReturn(value){
    return this.http.put('http://localhost:3350/returnproduct'+'/'+value._id,value)
  }
  deleteReturn(id){
    return this.http.delete('http://localhost:3350/returnproduct'+'/'+id)
  }
}
